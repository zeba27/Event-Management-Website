<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="with=device-width, initial-scale=1.0"> 
        <title> Review</title>
        <link rel="stylesheet" href="Style.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Dancing+Script&display=swap" rel="stylesheet">
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
     </head>
    <body>
        <section class="sub-header">
            <nav>
                <div class="evento-link">
                    <a href="Event.php" style=" text-decoration: none;">
                        <h2>even<b>T</b>prime</h2>
                     </a>
                </div>
                <div class="nav-links" id="navLinks">
                    <i class="fa fa-times-circle-o" onclick="hideMenu()"></i>
                    <ul>
                        <li><a href="Event.php"> HOME</a></li>
                        <li><a href="About.php"> ABOUT</a></li>
                        <li><a href="Services.php"> SERVICES</a></li>
                        <li><a href="Review.php"> REVIEWS</a></li>
                        <li><a href="Contact.php"> CONTACT</a></li>
                    </ul>
                </div>
                <i class="fa fa-bars" onclick="showMenu()"></i>
            </nav>
            <h1>What our client says</h1>
        </section>

        <div class="row">
            <div class="reviews-col">
                <img src="Images/Shamanta.jpg" width="150" height="150">
                <div>
                    <p>It was an amazing experience with event prime.<br>A big thank you to the team eventprime for letting me arrange the best event out there.</p>
                    <h3>Shamanta Rezwana</h3>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
            </div>
            <div class="reviews-col">
                <img src="Images/Shaikat.jpg" width="150" height="150">
                <div>
                    <p>It was an amazing experience with event prime.<br>A big thank you to the team eventprime for letting me arrange the best event out there.</p>
                    <h3>Rezvey Haque Saikat</h3>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-half-o"></i>
                </div>
            </div>

        </div>
        <div class="comment-box">
            <h3>Leave a comment</h3>
            <form class="comment-form">
                <input type="text" placeholder="Enter Name">
                <input type="email" placeholder="Enter Email">
                <textarea rows="5" placeholder="Your comment"></textarea>
                <button type="submit" class="log-btn red-btn">
                    POST COMMENT</button>

            </form>

        </div>
      </section>

        
        
      <section class="footer">
            
        <h5>Contact us on</h5>
        <div class="icons">
            <i class="fa fa-facebook"></i>
            <i class="fa fa-twitter"></i>
            <i class="fa fa-instagram"></i>
            <i class="fa fa-linkedin"></i>
        </div>
        <h5>01858195408</h5>
        <h5>Email us : eventprime@gmail.com</h5>
    </section>




    
        <script>
            var navLinks = document.getElementById("navLinks");
            function showMenu(){
                navLinks.style.right = "0";
            }
            function hideMenu(){
                navLinks.style.right = "-200px";
            }
        </script>
    </body>
</html>


