<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="with=device-width, initial-scale=1.0"> 
        <title> About the website</title>
        <link rel="stylesheet" href="Style.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Dancing+Script&display=swap" rel="stylesheet">
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
     </head>
    <body>
        <section class="sub-header">
            <nav>
                <div class="evento-link">
                    <a href="Event.php" style=" text-decoration: none;">
                        <h2>even<b>T</b>prime</h2>
                     </a>
                </div>
                <div class="nav-links" id="navLinks">
                    <i class="fa fa-times-circle-o" onclick="hideMenu()"></i>
                    <ul>
                        <li><a href="Event.php"> HOME</a></li>
                        <li><a href="About.php"> ABOUT</a></li>
                        <li><a href="Services.php"> SERVICES</a></li>
                        <li><a href="Review.php"> REVIEWS</a></li>
                        <li><a href="Contact.php"> CONTACT</a></li>
                    </ul>
                </div>
                <i class="fa fa-bars" onclick="showMenu()"></i>
            </nav>
            <h1>About Us</h1>
        </section>

        <section class="about-us">
            <div class="row">
                <div class="about-col">
                    <h3>Here is your biggest event management platform of the country.</h3>
                    <p>With a perfect blend of experience and passion,Eventprime is an event management company in Bangladesh. We have emerged as a company with ideas to turn your corporate or personal event into something worth remembering. With the help of our creative team, we provide our services to most types of corporate events including, but not limited to, seminars, conferences, trade shows, cultural events, company or organization milestones, exhibitions, product launches, concerts, company annual meetings, corporate picnics, fashion shows and appreciation events. We will also strive to make your wedding events, birthday events and other personal events unforgettable.</p>
                    <a href="Services.php" class="log-btn color-btn">EXPLORE NOW</a>
                </div>
                <div class="about-col">
                    <img src="images/aboutpic.jpg">
                </div>

            </div>


        </section>
        
        
        <section class="footer">
            
            <h5>Contact us on</h5>
            <div class="icons">
                <i class="fa fa-facebook"></i>
                <i class="fa fa-twitter"></i>
                <i class="fa fa-instagram"></i>
                <i class="fa fa-linkedin"></i>
            </div>
            <h5>01858195408</h5>
            <h5>Email us : eventprime@gmail.com</h5>
        </section>




    
        <script>
            var navLinks = document.getElementById("navLinks");
            function showMenu(){
                navLinks.style.right = "0";
            }
            function hideMenu(){
                navLinks.style.right = "-200px";
            }
        </script>
    </body>
</html>


