<?php 
include 'config.php';
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: index.php");
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="with=device-width, initial-scale=1.0"> 
        <title> Event management website</title>
        <link rel="stylesheet" href="Style.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Dancing+Script&display=swap" rel="stylesheet">
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
     </head>
    <body>
        <section class="header">
            <nav id="navbar">
                <div class="evento-link">
                    <a href="Event.php" style="text-decoration: none;">
                        <h2>even<b>T</b>prime</h2>
                     </a>
                </div>
                <div class="nav-links" id="navLinks">
                    <i class="fa fa-times-circle-o" onclick="hideMenu()"></i>
                    <ul>
                        <li><a href="Event.php"> HOME</a></li>
                        <li><a href="About.php"> ABOUT</a></li>
                        <li><a href="Services.php"> SERVICES</a></li>
                        <li><a href="Review.php"> REVIEWS</a></li>
                        <li><a href="Contact.php"> CONTACT</a></li>
                    </ul>
                </div>
                <i class="fa fa-bars" onclick="showMenu()"></i>
            </nav>
            </section>
            <div class="text-box">
                <?php
                if($_SESSION['email'] ){
                    $email=$_SESSION['email'];
                    $sql = "SELECT username FROM users where email='$email'";
                    $query = $conn->query($sql);
           $user = mysqli_fetch_assoc($query);
           if($query->num_rows>0){
               echo" <span style='font-size:40px;'><b> Welcome " . $user['username'] . "</b></span> <br> <br>";
           }}?>
                <a href="end.php" class="log-btn">Log Out</a>
            </div>
            
        
        <section class="services">
            <h1>Services We Offer</h1>
            <div class="row">
                <div class="service-col"><a href="Food.php" style="text-decoration: none;">
                    <img src="Images/food.jpg" height="150px">
                    <h3>Food</h3>
                    <p>
                        Food is an essential part of any socializing event and it is really important to serve food according to the theme of the event.We can help you choosing them.
                    </p>
                </a>
                </div>
                <div class="service-col"><a href="Light.php" style="text-decoration: none;">
                    <img src="Images/light.jpg" height="150px">
                    <h3>Lighting system</h3>
                    <p>
                        Professional lighting illuminates exactly what you want your audience to look at in any given moment. Create an amazing environment with amazing lighting.
                    </p>
                </a>

                </div>
                <div class="service-col"><a href="Sound.php" style="text-decoration: none;">
                    <img src="Images/sound.jpg" height="150px">
                    <h3>Sound system</h3>
                    <p>
                        It is really important to reach the audience.For that you need clear sound and all. We can help you with that.
                    </p>
                    </a>
                </div>
        </section>
        <section class="services">
            <div class="row">
                <div class="service-col"><a href="Photo.php" style="text-decoration: none;">
                    <img src="Images/photo.jpg" height="150px">
                    <h3>Photography</h3>
                    <p>
                        We all love to keep memory of any event. What can be a better option other than photography and videography?! We can do that for you.
                    </p>
                    </a>
                </div>
                <div class="service-col"><a href="Decors.php" style="text-decoration: none;">
                    <img src="Images/decor.jpg" height="150px">
                    <h3>Decors</h3>
                    <p>
                        A better environment is a must for a better experience. We can help you decorating the event location and you can get your desired environment.
                    </p>
                    </a>
                </div>
                <div class="service-col"><a href="Goods.php" style="text-decoration: none;">
                    <img src="Images/goods.jpg" height="150px">
                    <h3>Furnitures and goods</h3>
                    <p>
                        Extra furnitures and goods might be needed for a huge audience. Choose the perfect stuff for your perfect event with us.
                    </p>
                    </a>
                </div>
            </div>
        </section>

        <section class="footer">
            
            <h5>Contact us on</h5>
            <div class="icons">
                <i class="fa fa-facebook"></i>
                <i class="fa fa-twitter"></i>
                <i class="fa fa-instagram"></i>
                <i class="fa fa-linkedin"></i>
            </div>
            <h5>01858195408</h5>
            <h5>Email us : eventprime@gmail.com</h5>
        </section>











        
    
        <script>
            var navLinks = document.getElementById("navLinks");
            function showMenu(){
                navLinks.style.right = "0";
            }
            function hideMenu(){
                navLinks.style.right = "-200px";
            }
        </script>
       
        
      

    </body>
</html>


