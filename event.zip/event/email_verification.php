<?php
include 'config.php';
    session_start();
    if (isset($_POST['verify_email']))
    {
        $email = $_SESSION['email'];
        $verification_code = $_POST["verification_code"];
 
        // // connect with database
        // $con = new mysqli('localhost','root','','login_db');
        // if(!$con){
        //     echo 'Not connect';
        //}
 
        // mark email as verified
        $sql = "UPDATE users SET email_verified_at = NOW() WHERE email ='$email' AND verification_code = '$verification_code'";
        $result  = mysqli_query($conn, $sql);
 
        if (mysqli_affected_rows($conn) == 0)
        {
            die("Verification code failed.");
        }
        unset($_SESSION['email']);
       // echo "<p>You can login now.</p>";
        header('location:index.php?registered');
        exit();
    }
 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="email_verification.css">
   
    <title>Document</title>
</head>
<body>
<div class="verify_form">
<?php
        if(isset($_GET['email'])){
            echo "<h4 style='color:white;text-align: center;margin: 0;font-size: 16px;padding: 0;font-weight: bold;'>Verify your email first!!!</h4>";
        }
        ?>
<form method="POST">
    <input type="hidden" name="email" value="<?php echo $_GET['email']; ?>" required>
    <input type="text" name="verification_code" placeholder="Enter verification code" required />
 
    <button type="submit" name="verify_email" value="Verify Email">Verify Email</button>
</form>
</div>
</body>
</html>