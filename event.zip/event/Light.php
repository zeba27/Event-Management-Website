<?php
session_start();
include 'config.php';
session_start();
if($_SESSION['email']){
    
    $email=$_SESSION['email'];

    if (isset($_POST['submit'])) {
        $e_type= $_POST['e_type'];
        $event_details = $_POST['event_details'];
        $suggestion = $_POST['suggestion'];
        
    
        $sql = "INSERT INTO light (e_type,event_details, suggestion,email) VALUES ('$e_type','$event_details','$suggestion','$email')";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            echo "<script>alert('Yeee! Data inserted')</script>";
        } else {
            echo "<script>alert('Woops! Try agian.')</script>";
        }
    }}
    else{
        header('location:index.php');
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="with=device-width, initial-scale=1.0"> 
        <title>Light</title>
        <link rel="stylesheet" href="Style.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Dancing+Script&display=swap" rel="stylesheet">
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
     </head>
    <body>
        <section class="sub-header">
            <nav>
                <div class="evento-link">
                    <a href="Event.php" style=" text-decoration: none;">
                        <h2>even<b>T</b>prime</h2>
                     </a>
                </div>
                <div class="nav-links" id="navLinks">
                    <i class="fa fa-times-circle-o" onclick="hideMenu()"></i>
                    <ul>
                        <li><a href="Event.php"> HOME</a></li>
                        <li><a href="About.php"> ABOUT</a></li>
                        <li><a href="Services.php"> SERVICES</a></li>
                        <li><a href="Review.php"> REVIEWS</a></li>
                        <li><a href="Contact.php"> CONTACT</a></li>
                        <li><a href="end.php">LOGOUT</a></li>
                    </ul>
                </div>
                <i class="fa fa-bars" onclick="showMenu()"></i>
            </nav>
            <h1>About Lighting</h1>
        </section>

        <section class="contact-us">
            <div class="row">
                <div class="contact-col">
                    <img src="Images/lightinfo.jpg" height="320px">   
                </div>

                <div class="contact-col">
                    <form action="" method="POST">
                        <input type="text" name="e_type" placeholder="Enter the type of your event" required>
                        <input type="text" name="event_details" placeholder="Enter the day and time of your event" required>
                        <textarea rows="8" name="suggestion" placeholder="Please write any detail you want us to follow" required></textarea>
                        <button type="submit" name="submit" class="log-btn redd-btn">Send 

                        </button>
                    </form>

                </div>
            </div>
        </section>

        <section class="footer">
            
            <h5>Contact us on</h5>
            <div class="icons">
                <i class="fa fa-facebook"></i>
                <i class="fa fa-twitter"></i>
                <i class="fa fa-instagram"></i>
                <i class="fa fa-linkedin"></i>
            </div>
            <h5>01858195408</h5>
            <h5>Email us : eventprime@gmail.com</h5>
        </section>




    
        <script>
            var navLinks = document.getElementById("navLinks");
            function showMenu(){
                navLinks.style.right = "0";
            }
            function hideMenu(){
                navLinks.style.right = "-200px";
            }
        </script>
    </body>
</html>

