<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="with=device-width, initial-scale=1.0"> 
        <title>Contact</title>
        <link rel="stylesheet" href="Style.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Dancing+Script&display=swap" rel="stylesheet">
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
     </head>
    <body>
        <section class="sub-header">
            <nav>
                <div class="evento-link">
                    <a href="Event.php" style=" text-decoration: none;">
                        <h2>even<b>T</b>prime</h2>
                     </a>
                </div>
                <div class="nav-links" id="navLinks">
                    <i class="fa fa-times-circle-o" onclick="hideMenu()"></i>
                    <ul>
                        <li><a href="Event.php"> HOME</a></li>
                        <li><a href="About.php"> ABOUT</a></li>
                        <li><a href="Services.php"> SERVICES</a></li>
                        <li><a href="Review.php"> REVIEWS</a></li>
                        <li><a href="Contact.php"> CONTACT</a></li>
                    </ul>
                </div>
                <i class="fa fa-bars" onclick="showMenu()"></i>
            </nav>
            <h1>Contact Us</h1>
        </section>

        <section class="location">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d58144.49451615487!2d88.57099626626204!3d24.380228204744057!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39fbefa96a38d031%3A0x10f93a950ed6f410!2sRajshahi!5e0!3m2!1sen!2sbd!4v1661377931688!5m2!1sen!2sbd" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

        </section>

        <section class="contact-us">
            <div class="row">
                <div class="contact-col">
                    <div>
                        <i class="fa fa-home"></i> 
                        <span>
                            <h5>350,senpara parbata</h5>
                            <p>Talaimari,Rajshahi</p>
                        </span>
                    </div>
                    <div>
                        <i class="fa fa-phone"></i> 
                        <span>
                            <h5>+880 01858195408</h5>
                            <p>Saturday to Friday,8 AM to 5 PM</p>
                        </span>
                    </div>
                    <div>
                        <i class="fa fa-envelope-o"></i> 
                        <span>
                            <h5>eventprime@gmail.com</h5>
                            <p>Email us your query</p>
                        </span>
                    </div>

                    <div>
                        <i class="fa fa-twitter"></i> 
                        <span>
                            <h5>eventprime@twitter.com</h5>
                        </span>  
                    </div>
                </div>

                <div class="contact-col">
                    <form action="">
                        <input type="text" placeholder="Enter your name" required>
                        <input type="email" placeholder="Enter your email address" required>
                        <input type="text" placeholder="Enter the service you need" required>
                        <textarea rows="8" placeholder="Message" required></textarea>
                        <button type="submit" class="log-btn redd-btn">Send Message

                        </button>
                    </form>

                </div>
            </div>
        </section>
        
        <section class="footer">
            
            <h5>Contact us on</h5>
            <div class="icons">
                <i class="fa fa-facebook"></i>
                <i class="fa fa-twitter"></i>
                <i class="fa fa-instagram"></i>
                <i class="fa fa-linkedin"></i>
            </div>
            <h5>01858195408</h5>
            <h5>Email us : eventprime@gmail.com</h5>
        </section>




    
        <script>
            var navLinks = document.getElementById("navLinks");
            function showMenu(){
                navLinks.style.right = "0";
            }
            function hideMenu(){
                navLinks.style.right = "-200px";
            }
        </script>
    </body>
</html>


